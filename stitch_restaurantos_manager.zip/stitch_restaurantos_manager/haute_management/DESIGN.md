---
name: Haute Management
colors:
  surface: '#111316'
  surface-dim: '#111316'
  surface-bright: '#37393d'
  surface-container-lowest: '#0c0e11'
  surface-container-low: '#1a1c1f'
  surface-container: '#1e2023'
  surface-container-high: '#282a2d'
  surface-container-highest: '#333538'
  on-surface: '#e2e2e6'
  on-surface-variant: '#d0c5af'
  inverse-surface: '#e2e2e6'
  inverse-on-surface: '#2f3034'
  outline: '#99907c'
  outline-variant: '#4d4635'
  surface-tint: '#e9c349'
  primary: '#f2ca50'
  on-primary: '#3c2f00'
  primary-container: '#d4af37'
  on-primary-container: '#554300'
  inverse-primary: '#735c00'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffbec4'
  on-tertiary: '#670020'
  tertiary-container: '#ff94a1'
  on-tertiary-container: '#8e002f'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffe088'
  primary-fixed-dim: '#e9c349'
  on-primary-fixed: '#241a00'
  on-primary-fixed-variant: '#574500'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffd9dc'
  tertiary-fixed-dim: '#ffb2ba'
  on-tertiary-fixed: '#400010'
  on-tertiary-fixed-variant: '#910130'
  background: '#111316'
  on-background: '#e2e2e6'
  surface-variant: '#333538'
typography:
  display-hero:
    fontFamily: Playfair Display
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
  h1-header:
    fontFamily: Playfair Display
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.3'
  h2-subhead:
    fontFamily: Playfair Display
    fontSize: 24px
    fontWeight: '500'
    lineHeight: '1.4'
  body-main:
    fontFamily: Outfit
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  body-sm:
    fontFamily: Outfit
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: -0.02em
  label-caps:
    fontFamily: Outfit
    fontSize: 11px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.05em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  grid-columns: '12'
  gutter: 16px
  margin: 32px
---

## Brand & Style

The design system is engineered to evoke the precision of a Michelin-starred kitchen. It balances the "Back of House" efficiency with "Front of House" elegance. The style is a hybrid of **Minimalism** and **Glassmorphism**, utilizing deep, nocturnal backgrounds to allow data and status indicators to glow with purpose.

The target audience consists of high-end restaurateurs and floor managers who require a high-density information display that doesn't sacrifice aesthetic sophistication. The UI should feel like a premium tool—heavy, reliable, and expertly crafted.

## Colors

The palette is anchored in a dark, high-contrast environment to minimize eye strain during long shifts.

- **Primary (Chef's Gold):** Used exclusively for high-intent actions, primary buttons, and selected states.
- **Success (Emerald Green):** Indicates available tables, completed orders, or positive financial deltas.
- **Occupied (Muted Ruby):** Reserved for busy tables, pending tickets, or urgent attention areas.
- **Neutral/Background:** A progression of Deep Charcoal (#0A0B0D) for the canvas and Slate (#1E293B) for elevated containers.

## Typography

This design system employs a tri-font strategy to differentiate between brand, interface, and utility:

1.  **Playfair Display:** Used for page titles, section headers, and guest names to inject a sense of luxury and hospitality.
2.  **Outfit:** The primary workhorse for the UI. It provides high readability for menu items, descriptions, and navigation.
3.  **JetBrains Mono:** Dedicated to technical data—order IDs, timestamps, pricing units, and table numbers. The monospaced nature ensures vertical alignment in dense tables.

## Layout & Spacing

The system follows a strict **12-column fluid grid** for dashboard views, transitioning to a fixed-width centered column for settings and administrative tasks.

- **Rhythm:** A 4px baseline grid governs all spacing.
- **Density:** High-density layouts are preferred for the kitchen display and floor plan views to minimize scrolling. 
- **Gutters:** Standardized 16px gutters ensure that even with high data density, the information remains legible and distinct.

## Elevation & Depth

Depth is communicated through **Glassmorphism** and tonal layering rather than traditional heavy shadows.

- **Surface Levels:** The background is the lowest level. Cards and modules "float" using a semi-transparent slate background (`rgba(30, 41, 59, 0.7)`) with a 12px backdrop blur.
- **Borders:** Every container features a 1px solid border. Use `rgba(255, 255, 255, 0.1)` for standard containers and the Chef's Gold at low opacity for active/focused containers.
- **Active State:** Elements requiring immediate attention use a subtle outer glow of their functional color (Gold, Green, or Ruby) rather than a shadow.

## Shapes

The design system utilizes a **Sharp-Modern** aesthetic. 
- **Standard Corners:** A uniform 4px radius is applied to all buttons, cards, and input fields to maintain a professional, architectural feel.
- **Interactive Elements:** Buttons maintain the 4px radius, while status "pills" may use a full 100px radius to differentiate them as non-button indicators.
- **Icons:** Use Lucide icons with a 1.5px stroke weight to match the delicate borders of the UI components.

## Components

- **Buttons:** Primary buttons are solid 'Chef's Gold' with black 'Outfit' text. Secondary buttons are ghost-style with white text and 1px borders.
- **Cards:** Utilize the glassmorphism effect. Headers within cards should be separated by a hairline divider (1px).
- **Status Indicators:** Small circular pips or subtle background washes. Emerald Green for 'Available', Muted Ruby for 'Occupied/Late'.
- **Inputs:** Darker than the card background, using 'JetBrains Mono' for text entry to emphasize precision. Borders should brighten on focus.
- **Floor Plan Nodes:** Geometric representations of tables. Use sharp 4px corners. Table numbers should be rendered in 'JetBrains Mono'.
- **Modals:** Centered with a high backdrop blur (20px) on the content behind it, creating a "focus mode" for the user.
- **Data Tables:** Zebra striping is discouraged; instead, use thin 1px horizontal dividers and highlight rows on hover using a slight increase in background opacity.